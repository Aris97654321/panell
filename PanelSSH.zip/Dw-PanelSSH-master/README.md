# Dw-PanelSSH
Web Panel To Create SSH Account on Linux
<br><br>
<b>Fitur : </b><br>
1. Sistem Reseller / Deposit <br>
2. User Friendly <br>
3. CI & Mysqli <br>
4. Auto Create User Account <br>
5. Faktur / Invoice <br>
<br>
<b>Admin Area :</b><br>
1. Dashboard <br>
2. Manajemen Server <br>
3. Manajemen Akun <br>
4. Manajemen Invoice <br>
5. Pengaturan <br>
<br>
<b>Client Area :</b> <br>
1. Select Server<br>
2. Manajemen Akun Aktif <br>
3. Tambah Deposit <br>
4. Upload Bukti Pembayaran <br>
5. Status Invoice <br>
6. Total Saldo / Deposit <br>
7. Pengaturan <br>
<br>
<b><< TUTORIAL INSTALASI | DW-PanelSSH>></b> <br>
1. Upload Database yang kami sertakan kedalam PHPMyAdmin <br>
2. Masuk ke folder Application > config > config.php <br>
3. Pada $config['base_url'] isi dengan URL tempat anda menyimpan file projectnya, kemudian save. <br>
4. Masuk ke folder Application > config > database.php <br>
5. Pada $db['default'] ubah bagian Username, Password, Database dengan configurasi database anda.<br>
<br>
<b>Login Admin Default : </b><br>
Username : admin <br>
Password : admin<br>
<br>
<b>Demo :</b><br>
Client Area : http://dev.makassarnetwork.info/panelssh<br>
Admin Area : http://dev.makassarnetwork.info/panelssh/index.php/admin
